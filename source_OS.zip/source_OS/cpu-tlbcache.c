/*
 * Copyright (C) 2024 pdnguyen of the HCMC University of Technology
 */
/*
 * Source Code License Grant: Authors hereby grants to Licensee 
 * a personal to use and modify the Licensed Source Code for 
 * the sole purpose of studying during attending the course CO2018.
 */
#ifdef CPU_TLB
/*
 * Memory physical based TLB Cache
 * TLB cache module tlb/tlbcache.c
 *
 * TLB cache is physically memory phy
 * supports random access 
 * and runs at high speed
 */


#include "mm.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

static int TLB_NUM_OF_ENTRIES;

#ifdef FULLY_ASSOCIATE

#define TLB_PID_TAG_HIBIT 29
#define TLB_PID_TAG_LOBIT 14

#define TLB_PGN_TAG_HIBIT 13
#define TLB_PGN_TAG_LOBIT 0

#define TLB_VALID_TAG_MASK BIT(31)
#define TLB_USED_TAG_MASK BIT(30)
#define TLB_PID_TAG_MASK GENMASK(TLB_PID_TAG_HIBIT, TLB_PID_TAG_LOBIT)
#define TLB_PGN_TAG_MASK GENMASK(TLB_PGN_TAG_HIBIT, TLB_PGN_TAG_LOBIT)

#define TLB_VALID_TAG(x) GETVAL(x, TLB_VALID_TAG_MASK, 31)
#define TLB_USED_TAG(x) GETVAL(x, TLB_USED_TAG_MASK, 30)
#define TLB_PID_TAG(x) GETVAL(x, TLB_PID_TAG_MASK, TLB_PID_TAG_LOBIT)
#define TLB_PGN_TAG(x) GETVAL(x, TLB_PGN_TAG_MASK, TLB_PGN_TAG_LOBIT)

#endif

#ifdef DIRECT_MAP

#define TLB_PID_TAG_HIBIT 30
#define TLB_PID_TAG_LOBIT 14

#define TLB_PGN_TAG_HIBIT 13
#define TLB_PGN_TAG_LOBIT 0

#define TLB_VALID_TAG_MASK BIT(31)
#define TLB_PID_TAG_MASK GENMASK(TLB_PID_TAG_HIBIT, TLB_PID_TAG_LOBIT)
#define TLB_PGN_TAG_MASK GENMASK(TLB_PGN_TAG_HIBIT, TLB_PGN_TAG_LOBIT)

#define TLB_VALID_TAG(x) GETVAL(x, TLB_VALID_TAG_MASK, 31)
#define TLB_PID_TAG(x) GETVAL(x, TLB_PID_TAG_MASK, TLB_PID_TAG_LOBIT)
#define TLB_PGN_TAG(x) GETVAL(x, TLB_PGN_TAG_MASK, TLB_PGN_TAG_LOBIT)

#endif


#define init_tlbcache(mp,sz,...) init_memphy(mp, sz, (1, ##__VA_ARGS__))
static pthread_mutex_t tlb_lock;

/*
 *  tlb_cache_read read TLB cache device
 *  @mp: memphy struct
 *  @pid: process id
 *  @pgnum: page number
 *  @value: obtained value
 */
int tlb_cache_read(struct memphy_struct * mp, int pid, int pgnum, BYTE *value)
{
   /* TODO: the identify info is mapped to 
    *      cache line by employing:
    *      direct mapped, associated mapping etc.
    */
   if (pid < 0 || pid >= PID_MAX || mp == NULL)
     return -1;
  	
	pthread_mutex_lock(&tlb_lock);

#ifdef FULLY_ASSOCIATE
	int i;
	for(i = 0; i < TLB_NUM_OF_ENTRIES; i++) {
		uint32_t *tag = (uint32_t*)(mp->storage + i*8);
		uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 
	
		int tlb_valid = TLB_VALID_TAG(*tag);
		int tlb_pid = TLB_PID_TAG(*tag);	
		int tlb_pgnum = TLB_PGN_TAG(*tag);

		if(tlb_valid && tlb_pid == pid && tlb_pgnum == pgnum){
			*value = *frame;
			SETBIT(*tag, TLB_USED_TAG_MASK);
			pthread_mutex_unlock(&tlb_lock);
			return 0;
		}	
	}
#endif

#ifdef DIRECT_MAP
	int i = pgnum % TLB_NUM_OF_ENTRIES;

	uint32_t *tag = (uint32_t*)(mp->storage + i*8);
	uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 

	int tlb_valid = TLB_VALID_TAG(*tag);
	int tlb_pid = TLB_PID_TAG(*tag);	
	int tlb_pgnum = TLB_PGN_TAG(*tag);

	if(tlb_valid && tlb_pid == pid && tlb_pgnum == pgnum){
		*value = *frame;
		SETBIT(*tag, TLB_USED_TAG_MASK);
		pthread_mutex_unlock(&tlb_lock);
	}	return 0;
#endif

	pthread_mutex_unlock(&tlb_lock);
  	return 0;
}

/*
 *  tlb_cache_write write TLB cache device
 *  @mp: memphy struct
 *  @pid: process id
 *  @pgnum: page number
 *  @value: obtained value
 */
int tlb_cache_write(struct memphy_struct *mp, int pid, int pgnum, BYTE value)
{
   /* TODO: the identify info is mapped to 
    *      cache line by employing:
    *      direct mapped, associated mapping etc.
    */
   if (pid < 0 || pid >= PID_MAX || mp == NULL)
     return -1;

	pthread_mutex_lock(&tlb_lock);
	
#ifdef FULLY_ASSOCIATE
	int i; bool occupied = true;
	for(i = 0; i < TLB_NUM_OF_ENTRIES; i++) {
		uint32_t *tag = (uint32_t*)(mp->storage + i*8);
		uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 
	
		int tlb_valid = TLB_VALID_TAG(*tag);
		if(!valid) {
		SETBIT(*tag, TLB_VALID_TAG_MASK);
		SETBIT(*tag, TLB_USED_TAG_MASK);
		SETVAL(*tag, pid, TLB_PID_TAG_MASK, TLB_PID_TAG_LOBIT);
		SETVAL(*tag, pgnum, TLB_PGN_TAG_MASK, TLB_PGN_TAG_LOBIT);
		*frame = value;
		occupied = false; break;
		}
	}
	
	if(occupied) {
		uint32_t *tag = (uint32_t*)(mp->storage + i*8);
		uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 
	
		int tlb_used = TLB_USED_TAG(*tag);
		if(!tlb_used) {
		SETBIT(*tag, TLB_VALID_TAG_MASK);
		SETBIT(*tag, TLB_USED_TAG_MASK);
		SETVAL(*tag, pid, TLB_PID_TAG_MASK, TLB_PID_TAG_LOBIT);
		SETVAL(*tag, pgnum, TLB_PGN_TAG_MASK, TLB_PGN_TAG_LOBIT);
		*frame = value; break;	
		}
	}

	for(i = 0; i < TLB_NUM_OF_ENTRIES; i++) {
		uint32_t *tag = (uint32_t*)(mp->storage + i*8);
		CLRBIT(*tag, TLB_USED_TAG_MASK);
	}
#endif

#ifdef DIRECT_MAP
	int i = pgnum % TLB_NUM_OF_ENTRIES;

	uint32_t *tag = (uint32_t*)(mp->storage + i*8);
	uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 

	SETBIT(*tag, TLB_VALID_TAG_MASK);
	SETVAL(*tag, pid, TLB_PID_TAG_MASK, TLB_PID_TAG_LOBIT);
	SETVAL(*tag, pgnum, TLB_PGN_TAG_MASK, TLB_PGN_TAG_LOBIT);
	*frame = value;
#endif
	pthread_mutex_unlock(&tlb_lock);
	return 0;
}

/*
 *  TLBMEMPHY_read natively supports MEMPHY device interfaces
 *  @mp: memphy struct
 *  @addr: address
 *  @value: obtained value
 */
int TLBMEMPHY_read(struct memphy_struct * mp, int addr, BYTE *value)
{
   if (mp == NULL)
     return -1;

   /* TLB cached is random access by native */
   *value = mp->storage[addr];

   return 0;
}


/*
 *  TLBMEMPHY_write natively supports MEMPHY device interfaces
 *  @mp: memphy struct
 *  @addr: address
 *  @data: written data
 */
int TLBMEMPHY_write(struct memphy_struct * mp, int addr, BYTE data)
{
   if (mp == NULL)
     return -1;

   /* TLB cached is random access by native */
   mp->storage[addr] = data;

   return 0;
}

/*
 *  TLBMEMPHY_format natively supports MEMPHY device interfaces
 *  @mp: memphy struct
 */


int TLBMEMPHY_dump(struct memphy_struct * mp)
{
   /*TODO dump memphy contnt mp->storage 
    *     for tracing the memory content
    */
   if (mp == NULL) {return -1;}

   printf("Start dumping tlb memory content:\n");

#ifdef FULLY_ASSOCIATE
    int i;
    for (i = 0; i < TLB_NUM_OF_ENTRIES; i++) {
        uint32_t *tag = (uint32_t*)(mp->storage + i*8);
	uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 

	int tlb_valid = TLB_VALID_TAG(*tag);
	int tlb_used = TLB_USED_TAG(*tag);
	int tlb_pid = TLB_PID_TAG(*tag);
	int tlb_pgnum = TLB_PGN_TAG(*tag);

	printf("%02d %d %d %08d %08d %08d\n", i, valid, used, pid, pgnum, *frame);
    }
#endif

#ifdef DIRECT_MAP
    int i;
    for (i = 0; i < TLB_NUM_OF_ENTRIES; i++) {
        uint32_t *tag = (uint32_t*)(mp->storage + i*8);
	uint32_t *frame = (uint32_t*)(mp->storage + i*8 + 4); 

	int tlb_valid = TLB_VALID_TAG(*tag);
	int tlb_pid = TLB_PID_TAG(*tag);
	int tlb_pgnum = TLB_PGN_TAG(*tag);

	printf("%02d %d %08d %08d %08d\n", i, valid, pid, pgnum, *frame);
    }
#endif
   printf("End dumping tlb memory content:\n");
   return 0;
}


/*
 *  Init TLBMEMPHY struct
 */
int init_tlbmemphy(struct memphy_struct *mp, int max_size)
{
   mp->storage = (BYTE *)malloc(max_size*sizeof(BYTE));
   mp->maxsz = max_size;

   mp->rdmflg = 1;

	TLB_NUM_OF_ENTRIES = (mp->maxsz/8 > 8) ? 8 : (mp->maxsz/8);
	int i;
	for(i = 0; i < max_size; i++) {
		mp->storage[i] = 0;
	}	

	pthread_mutex_init(&tlb_lock, NULL);
   return 0;
}

#endif
