#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define N 5
#define NUM_PHIL 4

sem_t room, chops[N];

void *philosopher(void*);
void eat(int);
void think(int);
int main()
{
   int i, a[N];
   pthread_t tid[N];

   sem_init(&room, 0, NUM_PHIL);

   for (i = 0; i < N; i++)
      sem_init(&chops[i], 0, 1);

   for (i = 0; i < 5; i++)
   {
      a[i] = i;
      pthread_create(&tid[i], NULL, philosopher, (void*) &a[i]);
   }

   for (i = 0; i < 5; i++)
      pthread_join(tid[i], NULL);
}

void *philosopher(void *num)
{
   int phil = *(int*) num;
   printf("Philosopher %d has entered room\n", phil);

   while (1)
   {
      //sem_wait(&room);
      sem_wait(&chops[phil]);
      sem_wait(&chops[(phil + 1) % N]);

      printf("Philosopher %d takes fork %d and %d up\n",
	          phil, phil, (phil + 1) % N);

      eat(phil);
      sleep(2);

      printf("Philosopher %d puts fork %d and %d down\n", phil, phil, (phil + 1) % N);

      sem_post(&chops[(phil + 1) % N]);
      sem_post(&chops[phil]);
      //sem_post(&room);

      think(phil);
      sleep(1);
   }
}

void eat(int phil)
{
   printf("Philosopher %d is eating\n", phil);
}

void think(int phil)
{
   printf("Philosopher %d is thinking\n", phil);
}