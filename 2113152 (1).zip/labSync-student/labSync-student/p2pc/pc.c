#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>

#define MAX_ITEMS 1
#define THREADS 1 // 1 producer and 1 consumer
#define LOOPS 2 * MAX_ITEMS // variable
sem_t sem1;
sem_t sem2;

// Initiate shared buffer
int buffer[MAX_ITEMS];
int fill = 0;
int use = 0;
int flag_endPro = 0;
/*TODO: Fill in the synchronization stuff */
void put(int value); // put data into buffer
int get(); // get data from buffer

void * producer(void * arg) {
  int i;
  flag_endPro = 0;
  intptr_t tid = (intptr_t) arg;
  for (i = 0; i < LOOPS; i++) {
    sem_wait( &sem1);
    /*TODO: Fill in the synchronization stuff */
    put(i); // line P2
    printf("Producer %ld put data %d\n", tid, i);
    sleep(1);
    /*TODO: Fill in the synchronization stuff */
    sem_post( &sem2);
  }
  flag_endPro = 1;
  pthread_exit(NULL);
}

void * consumer(void * arg) {
  int i, tmp = 0;
  intptr_t tid = (intptr_t) arg;
  while (tmp != -1) {
    sem_wait( &sem2);
    /*TODO: Fill in the synchronization stuff */
    tmp = get(); // line C2
    printf("Consumer %ld get data %d\n", tid, tmp);
    sleep(1);
    /*TODO: Fill in the synchronization stuff */
    sem_post( &sem1);
    if (flag_endPro == 1) break;
  }
  pthread_exit(NULL);
}

int main(int argc, char ** argv) {
  //Create semaphore
  sem_init( &sem1, 0, MAX_ITEMS); // For producer
  sem_init( &sem2, 0, 0); // For consumer
  int i, j;
  intptr_t tid[THREADS];
  pthread_t producers[THREADS];
  pthread_t consumers[THREADS];

  /*TODO: Fill in the synchronization stuff */

  for (i = 0; i < THREADS; i++) {
    tid[i] = i;
    // Create producer thread
    pthread_create( & producers[i], NULL, producer, (void * ) tid[i]);

    // Create consumer thread
    pthread_create( & consumers[i], NULL, consumer, (void * ) tid[i]);
  }

  for (i = 0; i < THREADS; i++) {
    pthread_join(producers[i], NULL);
    pthread_join(consumers[i], NULL);
  }

  /*TODO: Fill in the synchronization stuff */
  return 0;
}

void put(int value) {
  buffer[fill] = value; // line f1
  fill = (fill + 1) % MAX_ITEMS; // line f2
}

int get() {
  int tmp = buffer[use]; // line g1
  use = (use + 1) % MAX_ITEMS; // line g2
  return tmp;
}
