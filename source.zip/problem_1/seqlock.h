#ifndef PTHREAD_H
#include <pthread.h>
#endif

typedef struct pthread_seqlock { /* TODO: implement the structure */
   pthread_spinlock_t spinlock;
   int flag;
   int numReader;
} pthread_seqlock_t;

static inline void pthread_seqlock_init(pthread_seqlock_t *rw)
{
   /* TODO: ... */
   pthread_spin_init(&rw -> spinlock, PTHREAD_PROCESS_SHARED);
   rw -> flag = 0;
   rw -> numReader = 0;
}

static inline void pthread_seqlock_wrlock(pthread_seqlock_t *rw)
{
   /* TODO: ... */
   if (rw -> numReader <= 1)
   {
      pthread_spin_lock(&rw -> spinlock);
      __sync_fetch_and_add(&rw -> flag, 1);
   }

}

static inline void pthread_seqlock_wrunlock(pthread_seqlock_t *rw)
{
   /* TODO: ... */
   __sync_fetch_and_sub(&rw -> flag, 1);
   pthread_spin_unlock(&rw -> spinlock);
}

static inline unsigned pthread_seqlock_rdlock(pthread_seqlock_t *rw)
{
   /* TODO: ... */
   if(rw -> flag % 2 == 0)
   {
      __sync_fetch_and_add(&rw -> numReader, 1);
      return 1;
   }
   return 0;
}


static inline unsigned pthread_seqlock_rdunlock(pthread_seqlock_t *rw)
{
   /* TODO: ... */
   if(rw -> flag % 2 == 0)
   {
      __sync_fetch_and_sub(&rw -> numReader, 1);
      return 1;
   } 
   return 0;
}

